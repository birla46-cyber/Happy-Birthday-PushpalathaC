HAPPY BIRTHDAY AMMA — WEBSITE FILES

Your website is a self-contained page. No photos, accounts, or extra libraries are needed.

PREVIEW ON YOUR DEVICE
1. Extract the ZIP file.
2. Open the happy-birthday-amma folder.
3. Open index.html in a browser (Chrome, Safari, Edge, or Firefox).

PUBLISH IT FREE WITH GITHUB PAGES
1. Sign in to https://github.com/ or create a free account.
2. Create a new public repository named exactly: happy-birthday-amma
3. Upload index.html to the repository's top level (not inside another folder).
4. Open the repository's Settings → Pages.
5. Under “Build and deployment”, choose “Deploy from a branch”.
6. Select branch “main” and folder “/ (root)”, then Save.
7. Wait a few minutes. Your shareable website address should be:
   https://YOUR-GITHUB-USERNAME.github.io/happy-birthday-amma/
   Replace YOUR-GITHUB-USERNAME with your GitHub username.

You can then share that link with Amma on WhatsApp. If GitHub asks you to verify an email or confirm settings, follow its on-screen steps.

EDITING
Open index.html in a text editor to change the birthday message or wording. Keep the filename as index.html.

PRIVACY
The page contains no tracking, forms, or personal photos. A public GitHub Pages site can be viewed by anyone who has its link (and may be discoverable), so avoid adding private information.
